/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.scheduler;

/**
 *
 * @author asus
 */
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

class Scheduler {
    static class Process {
        int id, arrivalTime, burstTime, remainingTime, completionTime, waitingTime, turnaroundTime, startTime = -1;
        
        Process(int id, int arrivalTime, int burstTime) {
            this.id = id;
            this.arrivalTime = arrivalTime;
            this.burstTime = burstTime;
            this.remainingTime = burstTime;
        }
    }

    public static void main(String[] args) {
        List<Process> processes = new ArrayList<>();
        int contextSwitchTime = 0, quantum = 0;
        
        try (BufferedReader br = new BufferedReader(new FileReader("input.txt"))) {
            String[] arrivalTimes = br.readLine().split(" ");
            String[] burstTimes = br.readLine().split(" ");
            
            for (int i = 0; i < arrivalTimes.length; i++) {
                processes.add(new Process(i + 1, Integer.parseInt(arrivalTimes[i]), Integer.parseInt(burstTimes[i])));
            }
            
            contextSwitchTime = Integer.parseInt(br.readLine());
            quantum = Integer.parseInt(br.readLine());
        } catch (IOException e) {
            System.out.println("Error reading input file.");
            return;
        }

        simulateFCFS(new ArrayList<>(processes), contextSwitchTime);
        simulateSRT(new ArrayList<>(processes), contextSwitchTime);
        simulateRR(new ArrayList<>(processes), contextSwitchTime, quantum);
    }
    
    private static void simulateFCFS(List<Process> processes, int contextSwitchTime) {
        int currentTime = 0;
        int totalWaitingTime = 0;
        int totalTurnaroundTime = 0;
        int idleTime = 0;
        int contextSwitches = 0;
        
        System.out.println("\nFCFS Scheduling:");
        System.out.print("Gantt Chart: ");
        for (Process p : processes) {
            if (currentTime < p.arrivalTime) {
                idleTime += (p.arrivalTime - currentTime);
                System.out.print(currentTime + " IDLE ");
                currentTime = p.arrivalTime;
            }
            
            p.waitingTime = currentTime - p.arrivalTime;
            System.out.print(currentTime + " P" + p.id + " ");
            currentTime += p.burstTime;
            p.completionTime = currentTime;
            p.turnaroundTime = p.completionTime - p.arrivalTime;
            
            totalWaitingTime += p.waitingTime;
            totalTurnaroundTime += p.turnaroundTime;
            
            if (processes.indexOf(p) != processes.size() - 1) {
                System.out.print(currentTime + " CS ");
                currentTime += contextSwitchTime;
                contextSwitches++;
            }
        }
        System.out.println(currentTime);
        
        printResults(processes, totalWaitingTime, totalTurnaroundTime, idleTime, contextSwitches, currentTime, contextSwitchTime);
    }
    
    private static void simulateSRT(List<Process> processes, int contextSwitchTime) {
        int currentTime = 0;
        int totalWaitingTime = 0;
        int totalTurnaroundTime = 0;
        int idleTime = 0;
        int completed = 0;
        int contextSwitches = 0;
        Process currentProcess = null;
        Queue<Process> readyQueue = new LinkedList<>();
        
        System.out.println("\nSRT Scheduling:");
        System.out.print("Gantt Chart: ");
        
        while (completed < processes.size()) {
            for (Process p : processes) {
                if (p.arrivalTime == currentTime) {
                    readyQueue.add(p);
                }
            }
            
            if (currentProcess == null || currentProcess.remainingTime == 0) {
                if (currentProcess != null && currentProcess.remainingTime == 0) {
                    currentProcess.completionTime = currentTime;
                    currentProcess.turnaroundTime = currentProcess.completionTime - currentProcess.arrivalTime;
                    currentProcess.waitingTime = currentProcess.turnaroundTime - currentProcess.burstTime;
                    totalWaitingTime += currentProcess.waitingTime;
                    totalTurnaroundTime += currentProcess.turnaroundTime;
                    completed++;
                }
                
                currentProcess = getShortestJob(readyQueue);
                if (currentProcess != null) {
                    readyQueue.remove(currentProcess);
                    if (!readyQueue.isEmpty() || completed > 0) {
                        System.out.print(currentTime + " CS ");
                        currentTime += contextSwitchTime;
                        contextSwitches++;
                    }
                    System.out.print(currentTime + " P" + currentProcess.id + " ");
                } else {
                    System.out.print(currentTime + " IDLE ");
                    idleTime++;
                    currentTime++;
                }
            } else {
                currentProcess.remainingTime--;
                currentTime++;
            }
        }
        System.out.println(currentTime);
        
        printResults(processes, totalWaitingTime, totalTurnaroundTime, idleTime, contextSwitches, currentTime, contextSwitchTime);
    }
    
    private static Process getShortestJob(Queue<Process> readyQueue) {
        Process shortest = null;
        for (Process p : readyQueue) {
            if (shortest == null || p.remainingTime < shortest.remainingTime) {
                shortest = p;
            }
        }
        return shortest;
    }
    
    private static void simulateRR(List<Process> processes, int contextSwitchTime, int quantum) {
        int currentTime = 0;
        int idleTime = 0;
        int contextSwitches = 0;
        Queue<Process> readyQueue = new LinkedList<>();
        List<Process> completedProcesses = new ArrayList<>();
        
        System.out.println("\nRR Scheduling:");
        System.out.print("Gantt Chart: ");
        
        while (!processes.isEmpty() || !readyQueue.isEmpty()) {
            for (Iterator<Process> it = processes.iterator(); it.hasNext();) {
                Process p = it.next();
                if (p.arrivalTime <= currentTime) {
                    readyQueue.add(p);
                    it.remove();
                }
            }
            
            if (readyQueue.isEmpty()) {
                idleTime++;
                System.out.print(currentTime + " IDLE ");
                currentTime++;
                continue;
            }
            
            Process currentProcess = readyQueue.poll();
            int timeSlice = Math.min(currentProcess.remainingTime, quantum);
            System.out.print(currentTime + " P" + currentProcess.id + " ");
            currentTime += timeSlice;
            currentProcess.remainingTime -= timeSlice;

            if (currentProcess.remainingTime > 0) {
                readyQueue.add(currentProcess);
            } else {
                currentProcess.completionTime = currentTime;
                currentProcess.turnaroundTime = currentProcess.completionTime - currentProcess.arrivalTime;
                completedProcesses.add(currentProcess);
            }
            
            if (!readyQueue.isEmpty() || !processes.isEmpty()) {
                System.out.print(currentTime + " CS ");
                currentTime += contextSwitchTime;
                contextSwitches++;
            }
        }
        System.out.println(currentTime);
        
        int totalWaitingTime = 0;
        int totalTurnaroundTime = 0;
        for (Process p : completedProcesses) {
            p.waitingTime = p.turnaroundTime - p.burstTime;
            if (p.waitingTime < 0) {
                p.waitingTime *= -1;
            }
            totalWaitingTime += p.waitingTime;
            totalTurnaroundTime += p.turnaroundTime;
        }
        
        printResults(completedProcesses, totalWaitingTime, totalTurnaroundTime, idleTime, contextSwitches, currentTime, contextSwitchTime);
    }
    
    private static void printResults(List<Process> processes, int totalWaitingTime, int totalTurnaroundTime, int idleTime, int contextSwitches, int currentTime, int contextSwitchTime) {
        System.out.println("Results:");
        for (Process p : processes) {
            System.out.println("Process P" + p.id + ": Finish Time = " + p.completionTime + ", Waiting Time = " + p.waitingTime + ", Turnaround Time = " + p.turnaroundTime);
        }
        System.out.println("Average Waiting Time: " + (float) totalWaitingTime / processes.size());
        System.out.println("Average Turnaround Time: " + (float) totalTurnaroundTime / processes.size());
        int totalContextSwitchTime = contextSwitches * contextSwitchTime;
        int totalIdleTime = idleTime;
        int totalBusyTime = currentTime - totalIdleTime - totalContextSwitchTime;
        System.out.println("CPU Utilization: " + (100 * ((float) totalBusyTime / currentTime)) + "%");
    }
}
